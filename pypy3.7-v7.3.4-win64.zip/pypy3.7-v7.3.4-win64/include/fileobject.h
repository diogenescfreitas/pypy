PyAPI_DATA(const char *) Py_FileSystemDefaultEncoding;
PyAPI_FUNC(void) _Py_setfilesystemdefaultencoding(const char *);
